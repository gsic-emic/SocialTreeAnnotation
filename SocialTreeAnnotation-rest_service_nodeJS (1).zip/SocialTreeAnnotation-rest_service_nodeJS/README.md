# SocialTreeAnotation / 2019-2020 GSIC-EMIC
Desarrollo de aplicación para anotación de árboles basada en web semántica.